// Copy this file to config.h and fill in your private credentials.
// Never commit config.h to a public repository.

#pragma once

#define BLYNK_TEMPLATE_ID "TMPLxxxxxxxx"
#define BLYNK_TEMPLATE_NAME "Smart Plant Care"
#define BLYNK_AUTH_TOKEN "YOUR_BLYNK_AUTH_TOKEN"

static const char WIFI_SSID[] = "YOUR_WIFI_SSID";
static const char WIFI_PASSWORD[] = "YOUR_WIFI_PASSWORD";

static constexpr uint32_t SERIAL_BAUD_RATE = 115200;
static constexpr uint8_t OLED_SDA_PIN = 21;
static constexpr uint8_t OLED_SCL_PIN = 22;
static constexpr uint8_t DHT_PIN = 4;
static constexpr uint8_t SOIL_SENSOR_PIN = 34;
static constexpr uint8_t MOTOR_ENA_PIN = 25;
static constexpr uint8_t MOTOR_IN1_PIN = 26;
static constexpr uint8_t MOTOR_IN2_PIN = 33;
static constexpr uint8_t BUZZER_PIN = 27;

static constexpr uint8_t SCREEN_WIDTH = 128;
static constexpr uint8_t SCREEN_HEIGHT = 64;
static constexpr int8_t OLED_RESET_PIN = -1;
static constexpr uint8_t OLED_I2C_ADDRESS = 0x3C;

static constexpr uint8_t DHT_TYPE = 11;
static constexpr bool DEFAULT_AUTO_MODE = true;
static constexpr uint32_t MOTOR_PWM_FREQUENCY_HZ = 20000UL;
static constexpr uint8_t MOTOR_PWM_RESOLUTION_BITS = 8;
static constexpr uint8_t PUMP_SPEED_PERCENT = 100;
static_assert(PUMP_SPEED_PERCENT <= 100, "PUMP_SPEED_PERCENT must be 0-100.");

static constexpr int SOIL_RAW_DRY = 4095;
static constexpr int SOIL_RAW_WET = 1500;
static constexpr int SOIL_DRY_THRESHOLD_PCT = 35;
static constexpr int SOIL_WET_THRESHOLD_PCT = 60;

static constexpr unsigned long SENSOR_READ_INTERVAL_MS = 2500UL;
static constexpr unsigned long CONTROL_INTERVAL_MS = 1000UL;
static constexpr unsigned long BLYNK_PUBLISH_INTERVAL_MS = 2000UL;
static constexpr unsigned long DISPLAY_REFRESH_INTERVAL_MS = 50UL;
static constexpr unsigned long DISPLAY_ANIMATION_STEP_MS = 50UL;
static constexpr unsigned long CONNECTIVITY_CHECK_INTERVAL_MS = 2000UL;
static constexpr unsigned long WIFI_RECONNECT_INTERVAL_MS = 7000UL;
static constexpr unsigned long BLYNK_RECONNECT_INTERVAL_MS = 5000UL;
static constexpr unsigned long STARTUP_ANIMATION_DURATION_MS = 3500UL;
static constexpr unsigned long HAPPY_SCREEN_DURATION_MS = 3500UL;
static constexpr unsigned long BUZZER_BEEP_INTERVAL_MS = 2000UL;
static constexpr unsigned long BUZZER_BEEP_ON_TIME_MS = 180UL;
static constexpr unsigned long METRICS_SCREEN_INTERVAL_MS = 10000UL;
static constexpr unsigned long METRICS_SCREEN_DURATION_MS = 5000UL;
static constexpr unsigned long MOOD_LABEL_INTERVAL_MS = 5000UL;
static constexpr unsigned long MOOD_LABEL_DURATION_MS = 1500UL;

static constexpr const char* BLYNK_EVENT_SOIL_DRY = "soil_dry";
static constexpr const char* BLYNK_EVENT_PUMP = "pump_status";
static constexpr const char* BLYNK_EVENT_HEALTHY = "plant_healthy";
static constexpr const char* BLYNK_EVENT_SYSTEM = "system_status";





