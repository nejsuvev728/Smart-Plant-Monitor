#include "config.h"
#include "bitmaps.h"
#include "animations.h"

#define BLYNK_PRINT Serial

#include <Wire.h>
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

enum SystemMode : uint8_t {
  MODE_STARTUP,
  MODE_WIFI_CONNECTING,
  MODE_WIFI_CONNECTED,
  MODE_HEALTHY,
  MODE_DRY_SOIL,
  MODE_WATERING,
  MODE_PLANT_HAPPY,
  MODE_SLEEPING
};

struct SensorData {
  float temperatureC = 0.0F;
  float humidityPct = 0.0F;
  int soilRaw = SOIL_RAW_DRY;
  int soilPct = 0;
  bool dhtValid = false;
};

struct RuntimeFlags {
  bool autoModeEnabled = DEFAULT_AUTO_MODE;
  bool manualPumpRequest = false;
  bool pumpRunning = false;
  bool soilDryAlertActive = false;
  bool sentDryNotification = false;
};

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET_PIN);
DHT dht(DHT_PIN, DHT_TYPE);
BlynkTimer timer;

SensorData sensorData;
RuntimeFlags flags;
SystemMode currentMode = MODE_STARTUP;
SystemMode lastMoodLabelMode = MODE_STARTUP;

bool displayReady = false;
bool motorPwmReady = false;
unsigned long startupAnimationStartedAt = 0UL;
unsigned long lastReconnectAttemptAt = 0UL;
unsigned long lastBuzzerToggleAt = 0UL;
unsigned long happyModeStartedAt = 0UL;
unsigned long lastDisplayFrameAt = 0UL;
unsigned long lastMoodLabelAt = 0UL;
uint32_t displayFrame = 0UL;
bool buzzerOutputState = false;

void initializeDisplay();
void initializePins();
void initializeConnectivity();
void updateConnectivity();
void attemptWiFiReconnect();
void attemptBlynkReconnect();
void readSensors();
int calculateSoilPercent(int rawValue);
void evaluatePlantState();
void applyPumpOutput(bool enabled);
void setPumpState(bool enabled, const char* reason);
void updateBuzzer();
void updateDisplay();
bool shouldShowMetricsScreen();
void drawMetricsScreen();
void drawStartupScreen();
void drawWiFiConnectingScreen();
void drawWiFiConnectedScreen();
void drawHealthyScreen();
void drawDrySoilScreen();
void drawWateringScreen();
void drawPlantHappyScreen();
void drawSleepingScreen();
void publishToBlynk();
void syncBlynkWidgets();
void sendBlynkEvent(const char* eventCode, const String& message);
void logStatus(const String& message);
String getLocalIpString();
const char* modeToLabel(SystemMode mode);

BLYNK_CONNECTED() {
  Blynk.syncVirtual(V3, V4);
  logStatus("Blynk connected.");
  sendBlynkEvent(BLYNK_EVENT_SYSTEM, String("Blynk connected. IP: ") + getLocalIpString());
  syncBlynkWidgets();
}

BLYNK_WRITE(V3) {
  flags.manualPumpRequest = param.asInt() == 1;
  if (!flags.autoModeEnabled) {
    setPumpState(flags.manualPumpRequest, "Manual Blynk request");
  }
}

BLYNK_WRITE(V4) {
  flags.autoModeEnabled = param.asInt() == 1;
  if (flags.autoModeEnabled) {
    flags.manualPumpRequest = false;
    evaluatePlantState();
  } else {
    setPumpState(flags.manualPumpRequest, "Manual mode enabled");
  }
  syncBlynkWidgets();
}

void setup() {
  Serial.begin(SERIAL_BAUD_RATE);
  delay(100);
  logStatus("Booting Smart Plant Monitor...");

  initializePins();
  initializeDisplay();
  dht.begin();
  initializeConnectivity();

  startupAnimationStartedAt = millis();
  currentMode = MODE_STARTUP;

  timer.setInterval(SENSOR_READ_INTERVAL_MS, []() { readSensors(); });
  timer.setInterval(CONTROL_INTERVAL_MS, []() { evaluatePlantState(); });
  timer.setInterval(BLYNK_PUBLISH_INTERVAL_MS, []() { publishToBlynk(); });
  timer.setInterval(DISPLAY_REFRESH_INTERVAL_MS, []() { updateDisplay(); });
  timer.setInterval(CONNECTIVITY_CHECK_INTERVAL_MS, []() { updateConnectivity(); });

  readSensors();
  updateDisplay();
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    Blynk.run();
  }

  timer.run();
  updateBuzzer();

  if (currentMode == MODE_STARTUP && millis() - startupAnimationStartedAt >= STARTUP_ANIMATION_DURATION_MS) {
    currentMode = (WiFi.status() == WL_CONNECTED) ? MODE_WIFI_CONNECTED : MODE_WIFI_CONNECTING;
  }
}

void initializePins() {
  pinMode(MOTOR_IN1_PIN, OUTPUT);
  pinMode(MOTOR_IN2_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(MOTOR_IN1_PIN, LOW);
  digitalWrite(MOTOR_IN2_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  motorPwmReady = ledcAttach(MOTOR_ENA_PIN, MOTOR_PWM_FREQUENCY_HZ, MOTOR_PWM_RESOLUTION_BITS);
  if (motorPwmReady) {
    ledcWrite(MOTOR_ENA_PIN, 0U);
  } else {
    logStatus("L298N ENA PWM initialization failed.");
  }
}

void initializeDisplay() {
  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
  displayReady = display.begin(SSD1306_SWITCHCAPVCC, OLED_I2C_ADDRESS);

  if (!displayReady) {
    logStatus("OLED initialization failed.");
    return;
  }

  display.clearDisplay();
  display.display();
}

void initializeConnectivity() {
  WiFi.mode(WIFI_STA);
  Blynk.config(BLYNK_AUTH_TOKEN);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  logStatus("WiFi connection started.");
}

void updateConnectivity() {
  if (WiFi.status() != WL_CONNECTED) {
    currentMode = MODE_WIFI_CONNECTING;
    attemptWiFiReconnect();
    return;
  }

  if (!Blynk.connected()) {
    attemptBlynkReconnect();
  }

  if (currentMode == MODE_WIFI_CONNECTING) {
    currentMode = MODE_WIFI_CONNECTED;
  }
}

void attemptWiFiReconnect() {
  const unsigned long now = millis();
  if (now - lastReconnectAttemptAt < WIFI_RECONNECT_INTERVAL_MS) {
    return;
  }

  lastReconnectAttemptAt = now;
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  logStatus("Retrying WiFi...");
}

void attemptBlynkReconnect() {
  const unsigned long now = millis();
  if (now - lastReconnectAttemptAt < BLYNK_RECONNECT_INTERVAL_MS) {
    return;
  }

  lastReconnectAttemptAt = now;
  if (Blynk.connect(2000)) {
    logStatus("Blynk reconnect successful.");
  } else {
    logStatus("Blynk reconnect pending...");
  }
}

void readSensors() {
  const float humidity = dht.readHumidity();
  const float temperature = dht.readTemperature();
  sensorData.dhtValid = !(isnan(humidity) || isnan(temperature));

  if (sensorData.dhtValid) {
    sensorData.humidityPct = humidity;
    sensorData.temperatureC = temperature;
  } else {
    logStatus("DHT11 read failed. Retaining last valid values.");
  }

  sensorData.soilRaw = analogRead(SOIL_SENSOR_PIN);
  sensorData.soilPct = calculateSoilPercent(sensorData.soilRaw);

  Serial.printf(
    "[Sensors] Temp: %.1f C | Humidity: %.1f %% | Soil raw: %d | Soil: %d %%\n",
    sensorData.temperatureC,
    sensorData.humidityPct,
    sensorData.soilRaw,
    sensorData.soilPct
  );
}

int calculateSoilPercent(int rawValue) {
  const int constrainedRaw = constrain(rawValue, SOIL_RAW_WET, SOIL_RAW_DRY);
  const int mapped = map(constrainedRaw, SOIL_RAW_DRY, SOIL_RAW_WET, 0, 100);
  return constrain(mapped, 0, 100);
}

void evaluatePlantState() {
  const bool soilIsDry = sensorData.soilPct < SOIL_DRY_THRESHOLD_PCT;
  const bool soilRecovered = sensorData.soilPct > SOIL_WET_THRESHOLD_PCT;

  flags.soilDryAlertActive = soilIsDry;

  if (flags.autoModeEnabled) {
    if (soilIsDry && !flags.pumpRunning) {
      setPumpState(true, "Auto mode: soil dry");
    } else if (soilRecovered && flags.pumpRunning) {
      setPumpState(false, "Auto mode: soil recovered");
      happyModeStartedAt = millis();
      currentMode = MODE_PLANT_HAPPY;
    }
  } else {
    setPumpState(flags.manualPumpRequest, "Manual mode");
  }

  if (flags.pumpRunning) {
    currentMode = MODE_WATERING;
  } else if (currentMode == MODE_PLANT_HAPPY && millis() - happyModeStartedAt < HAPPY_SCREEN_DURATION_MS) {
    return;
  } else if (soilIsDry) {
    currentMode = MODE_DRY_SOIL;
  } else {
    currentMode = MODE_HEALTHY;
  }

  if (soilIsDry && !flags.sentDryNotification) {
    sendBlynkEvent(BLYNK_EVENT_SOIL_DRY, "Plant Needs Water");
    flags.sentDryNotification = true;
  } else if (!soilIsDry) {
    flags.sentDryNotification = false;
  }
}

void applyPumpOutput(bool enabled) {
  if (!enabled) {
    ledcWrite(MOTOR_ENA_PIN, 0U);
    digitalWrite(MOTOR_IN1_PIN, LOW);
    digitalWrite(MOTOR_IN2_PIN, LOW);
    return;
  }

  const uint32_t maximumDuty = (1UL << MOTOR_PWM_RESOLUTION_BITS) - 1UL;
  const uint32_t pumpDuty = (maximumDuty * PUMP_SPEED_PERCENT) / 100UL;

  digitalWrite(MOTOR_IN1_PIN, HIGH);
  digitalWrite(MOTOR_IN2_PIN, LOW);
  ledcWrite(MOTOR_ENA_PIN, pumpDuty);
}

void setPumpState(bool enabled, const char* reason) {
  if (enabled && !motorPwmReady) {
    logStatus("Pump start blocked: L298N PWM is unavailable.");
    return;
  }

  if (flags.pumpRunning == enabled) {
    return;
  }

  applyPumpOutput(enabled);
  flags.pumpRunning = enabled;

  if (enabled) {
    sendBlynkEvent(BLYNK_EVENT_PUMP, "Watering Started");
  } else {
    sendBlynkEvent(BLYNK_EVENT_HEALTHY, "Plant Healthy Again");
  }

  logStatus(String("Pump ") + (enabled ? "ON" : "OFF") + " | Reason: " + reason);
  syncBlynkWidgets();
}

void updateBuzzer() {
  if (!flags.soilDryAlertActive || flags.pumpRunning) {
    if (buzzerOutputState) {
      buzzerOutputState = false;
      digitalWrite(BUZZER_PIN, LOW);
    }
    return;
  }

  const unsigned long now = millis();
  if (now - lastBuzzerToggleAt >= BUZZER_BEEP_INTERVAL_MS) {
    lastBuzzerToggleAt = now;
    buzzerOutputState = true;
    digitalWrite(BUZZER_PIN, HIGH);
  } else if (buzzerOutputState && now - lastBuzzerToggleAt >= BUZZER_BEEP_ON_TIME_MS) {
    buzzerOutputState = false;
    digitalWrite(BUZZER_PIN, LOW);
  }
}

bool shouldShowMetricsScreen() {
  if (currentMode == MODE_STARTUP || currentMode == MODE_WIFI_CONNECTING || currentMode == MODE_WIFI_CONNECTED) {
    return false;
  }

  if (millis() < STARTUP_ANIMATION_DURATION_MS) {
    return false;
  }

  const unsigned long cycleMs = METRICS_SCREEN_INTERVAL_MS + METRICS_SCREEN_DURATION_MS;
  const unsigned long cyclePosition = millis() % cycleMs;
  return cyclePosition >= METRICS_SCREEN_INTERVAL_MS;
}

bool shouldShowMoodLabel() {
  if (currentMode == MODE_STARTUP || currentMode == MODE_WIFI_CONNECTING || currentMode == MODE_WIFI_CONNECTED) {
    return false;
  }

  const unsigned long now = millis();
  if (currentMode != lastMoodLabelMode || now - lastMoodLabelAt >= MOOD_LABEL_INTERVAL_MS) {
    lastMoodLabelMode = currentMode;
    lastMoodLabelAt = now;
  }

  return now - lastMoodLabelAt < MOOD_LABEL_DURATION_MS;
}
void updateDisplay() {
  if (!displayReady) {
    return;
  }

  if (millis() - lastDisplayFrameAt >= DISPLAY_ANIMATION_STEP_MS) {
    lastDisplayFrameAt = millis();
    displayFrame++;
  }

  display.clearDisplay();

  if (shouldShowMetricsScreen()) {
    drawMetricsScreen();
    display.display();
    return;
  }

  switch (currentMode) {
    case MODE_STARTUP:
      drawStartupScreen();
      break;
    case MODE_WIFI_CONNECTING:
      drawWiFiConnectingScreen();
      break;
    case MODE_WIFI_CONNECTED:
      drawWiFiConnectedScreen();
      break;
    case MODE_DRY_SOIL:
      drawDrySoilScreen();
      break;
    case MODE_WATERING:
      drawWateringScreen();
      break;
    case MODE_PLANT_HAPPY:
      drawPlantHappyScreen();
      break;
    case MODE_SLEEPING:
      drawSleepingScreen();
      break;
    case MODE_HEALTHY:
    default:
      drawHealthyScreen();
      break;
  }

  if (shouldShowMoodLabel()) {
    drawMoodLabel();
  }

  display.display();
}

void drawMoodLabel() {
  const char* label = "HEALTHY PLANT";

  switch (currentMode) {
    case MODE_DRY_SOIL:
      label = "THIRSTY PLANT";
      break;
    case MODE_WATERING:
      label = "WATERING";
      break;
    case MODE_PLANT_HAPPY:
      label = "PLANT HAPPY";
      break;
    case MODE_SLEEPING:
      label = "RESTING";
      break;
    case MODE_HEALTHY:
    default:
      break;
  }

  display.fillRect(0, 51, SCREEN_WIDTH, 13, SSD1306_BLACK);
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setTextWrap(false);
  const int16_t labelWidth = static_cast<int16_t>(strlen(label) * 6U);
  display.setCursor((SCREEN_WIDTH - labelWidth) / 2, 54);
  display.print(label);
}
void drawMetricsScreen() {
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);
  display.setTextSize(1);

  display.setCursor(2, 2);
  display.print("TEMP");
  display.setCursor(28, 2);
  if (sensorData.dhtValid) {
    display.print(sensorData.temperatureC, 1);
  } else {
    display.print("--.-");
  }
  display.print("C");

  display.setCursor(72, 2);
  display.print("HUM");
  display.setCursor(94, 2);
  if (sensorData.dhtValid) {
    display.print((int)sensorData.humidityPct);
  } else {
    display.print("--");
  }
  display.print("%");

  display.drawLine(0, 13, 127, 13, SSD1306_WHITE);

  display.setTextSize(2);
  display.setCursor(4, 18);
  display.print("SOIL");
  display.setCursor(64, 18);
  display.print(sensorData.soilPct);
  display.print("%");

  display.drawLine(0, 36, 127, 36, SSD1306_WHITE);

  display.setTextSize(1);
  display.setCursor(2, 40);
  display.print(flags.pumpRunning ? "PUMP:ON" : "PUMP:OFF");
  display.setCursor(68, 40);
  display.print(flags.autoModeEnabled ? "MODE:AUTO" : "MODE:MAN");

  display.setCursor(2, 53);
  display.print(WiFi.status() == WL_CONNECTED ? "WIFI:OK" : "WIFI:OFF");
  display.setCursor(68, 53);
  display.print(Blynk.connected() ? "BLYNK:OK" : "BLYNK:OFF");
}

void drawStartupScreen() {
  const uint8_t frame = getLoadingFrame(displayFrame);
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(2);
  display.setCursor(24, 10);
  display.print("SMART");
  display.setCursor(24, 28);
  display.print("PLANT");
  display.setTextSize(1);
  display.setCursor(32, 46);
  display.print("MONITOR");

  for (uint8_t i = 0; i < 5; i++) {
    const int x = 28 + (i * 14);
    if (i <= frame) {
      display.fillRoundRect(x, 56, 10, 4, 2, SSD1306_WHITE);
    } else {
      display.drawRoundRect(x, 56, 10, 4, 2, SSD1306_WHITE);
    }
  }
}

void drawWiFiConnectingScreen() {
  display.drawBitmap(10, 18, wifiSignalBitmap, 16, 16, SSD1306_WHITE);
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(2);
  display.setCursor(34, 16);
  display.print("WiFi");
  display.setTextSize(1);
  display.setCursor(34, 38);
  display.print("Connecting");
  for (uint8_t i = 0; i < getLoadingDots(displayFrame); i++) {
    display.print(".");
  }
}

void drawWiFiConnectedScreen() {
  display.drawBitmap(8, 14, wifiConnectedBitmap, 16, 16, SSD1306_WHITE);
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(30, 14);
  display.print("Connected");
  display.setCursor(30, 28);
  display.print(getLocalIpString());
  display.setCursor(30, 42);
  display.print(Blynk.connected() ? "Blynk Online" : "Blynk Syncing");
}

void drawHealthyScreen() {
  drawHappyFaceFrame(display, 0, 0, displayFrame);
}

void drawDrySoilScreen() {
  drawSadFaceFrame(display, 0, 0, displayFrame);
}

void drawWateringScreen() {
  drawWateringFaceFrame(display, 0, 0, displayFrame);
}

void drawPlantHappyScreen() {
  drawBigSmileFaceFrame(display, 0, 0, displayFrame);
}

void drawSleepingScreen() {
  drawSleepingFaceFrame(display, 0, 0, displayFrame);
}

void publishToBlynk() {
  if (!Blynk.connected()) {
    return;
  }

  Blynk.virtualWrite(V0, sensorData.temperatureC);
  Blynk.virtualWrite(V1, sensorData.humidityPct);
  Blynk.virtualWrite(V2, sensorData.soilPct);
  Blynk.virtualWrite(V3, flags.manualPumpRequest ? 1 : 0);
  Blynk.virtualWrite(V4, flags.autoModeEnabled ? 1 : 0);
  Blynk.virtualWrite(V5, flags.pumpRunning ? 255 : 0);
  Blynk.virtualWrite(V6, flags.soilDryAlertActive ? 1 : 0);
  Blynk.virtualWrite(V7, modeToLabel(currentMode));
}

void syncBlynkWidgets() {
  if (!Blynk.connected()) {
    return;
  }

  Blynk.virtualWrite(V3, flags.manualPumpRequest ? 1 : 0);
  Blynk.virtualWrite(V4, flags.autoModeEnabled ? 1 : 0);
  Blynk.virtualWrite(V5, flags.pumpRunning ? 255 : 0);
  Blynk.virtualWrite(V7, modeToLabel(currentMode));
}

void sendBlynkEvent(const char* eventCode, const String& message) {
  if (Blynk.connected()) {
    Blynk.logEvent(eventCode, message);
  }
  Serial.printf("[Event] %s -> %s\n", eventCode, message.c_str());
}

void logStatus(const String& message) {
  Serial.printf("[Status] %s\n", message.c_str());
}

String getLocalIpString() {
  return (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "0.0.0.0";
}

const char* modeToLabel(SystemMode mode) {
  switch (mode) {
    case MODE_STARTUP:
      return "Startup";
    case MODE_WIFI_CONNECTING:
      return "WiFi Connecting";
    case MODE_WIFI_CONNECTED:
      return "WiFi Connected";
    case MODE_HEALTHY:
      return "Healthy";
    case MODE_DRY_SOIL:
      return "Dry Soil";
    case MODE_WATERING:
      return "Watering";
    case MODE_PLANT_HAPPY:
      return "Plant Happy";
    case MODE_SLEEPING:
      return "Sleeping";
    default:
      return "Unknown";
  }
}








