#pragma once

#include <Adafruit_SSD1306.h>
#include "bitmaps.h"

enum RobotEyeMood : uint8_t {
  EYES_NORMAL,
  EYES_HAPPY,
  EYES_SAD,
  EYES_WATERING
};

inline uint8_t getLoadingFrame(uint32_t frame) {
  return frame % 5U;
}

inline uint8_t getLoadingDots(uint32_t frame) {
  return (frame % 4U) + 1U;
}

inline void drawRobotSparkle(Adafruit_SSD1306& display, int16_t x, int16_t y) {
  display.drawLine(x - 2, y, x + 2, y, SSD1306_WHITE);
  display.drawLine(x, y - 2, x, y + 2, SSD1306_WHITE);
}

// Moves both solid eye blocks together so they appear to look around.
inline int8_t getHorizontalGaze(uint32_t frame) {
  const uint8_t phase = frame % 72U;

  if (phase >= 8U && phase <= 13U) {
    return -static_cast<int8_t>(phase - 7U);
  }
  if (phase >= 14U && phase <= 21U) {
    return -6;
  }
  if (phase >= 22U && phase <= 27U) {
    return static_cast<int8_t>(phase - 27U);
  }
  if (phase >= 36U && phase <= 41U) {
    return static_cast<int8_t>(phase - 35U);
  }
  if (phase >= 42U && phase <= 49U) {
    return 6;
  }
  if (phase >= 50U && phase <= 55U) {
    return static_cast<int8_t>(55U - phase);
  }
  return 0;
}

// Compressing the eye height through several frames creates a natural blink.
inline uint8_t getBlinkHeight(uint32_t frame) {
  switch (frame % 104U) {
    case 92U:
    case 98U:
      return 26U;
    case 93U:
    case 97U:
      return 14U;
    case 94U:
    case 96U:
      return 6U;
    case 95U:
      return 3U;
    default:
      return 34U;
  }
}

inline int8_t getHappyBounce(uint32_t frame) {
  switch (frame % 72U) {
    case 60U:
    case 64U:
      return -1;
    case 61U:
    case 63U:
      return -2;
    case 62U:
      return -3;
    default:
      return 0;
  }
}

inline void drawRoundedRobotEye(Adafruit_SSD1306& display,
                                int16_t centerX,
                                int16_t centerY,
                                uint8_t width,
                                uint8_t height,
                                RobotEyeMood mood,
                                bool leftEye) {
  const int16_t x = centerX - (width / 2);
  const int16_t y = centerY - (height / 2);
  const uint8_t radius = (height < 16U) ? (height / 2U) : 8U;

  display.fillRoundRect(x, y, width, height, radius, SSD1306_WHITE);

  if (mood == EYES_SAD && height >= 16U) {
    // Removing the upper outside corners raises the inner corners.
    if (leftEye) {
      display.fillTriangle(x, y, x + 11, y, x, y + 10, SSD1306_BLACK);
    } else {
      display.fillTriangle(x + width - 1, y,
                           x + width - 12, y,
                           x + width - 1, y + 10,
                           SSD1306_BLACK);
    }
  }
}

inline void drawRobotEyePair(Adafruit_SSD1306& display,
                             uint32_t frame,
                             RobotEyeMood mood) {
  int8_t gazeX = getHorizontalGaze(frame);
  int8_t gazeY = 0;
  int8_t centerY = 29;
  uint8_t width = 38U;
  uint8_t maximumHeight = 34U;

  if (mood == EYES_HAPPY) {
    width = 40U;
    maximumHeight = 36U;
    centerY += getHappyBounce(frame);
  } else if (mood == EYES_SAD) {
    width = 36U;
    maximumHeight = 30U;
    centerY = 32;
    gazeY = 2;
    gazeX /= 2;
  } else if (mood == EYES_WATERING) {
    width = 36U;
    maximumHeight = 32U;
    centerY = 32;
    gazeY = -2;
  }

  const uint8_t blinkHeight = getBlinkHeight(frame);
  const uint8_t eyeHeight = (blinkHeight < maximumHeight) ? blinkHeight : maximumHeight;

  drawRoundedRobotEye(display, 37 + gazeX, centerY + gazeY,
                      width, eyeHeight, mood, true);
  drawRoundedRobotEye(display, 91 + gazeX, centerY + gazeY,
                      width, eyeHeight, mood, false);
}

inline void drawFallingDrop(Adafruit_SSD1306& display,
                            int16_t x,
                            uint32_t frame,
                            uint8_t phaseOffset) {
  const int16_t y = static_cast<int16_t>(((frame * 2U) + phaseOffset) % 78U) - 12;
  display.drawBitmap(x, y, waterDropBitmap, 8, 12, SSD1306_WHITE);
}

inline void drawHappyFaceFrame(Adafruit_SSD1306& display,
                               int16_t,
                               int16_t,
                               uint32_t frame) {
  drawRobotEyePair(display, frame, EYES_NORMAL);
}

inline void drawSadFaceFrame(Adafruit_SSD1306& display,
                             int16_t,
                             int16_t,
                             uint32_t frame) {
  drawRobotEyePair(display, frame, EYES_SAD);

  const int16_t leftTearY = 38 + static_cast<int16_t>(frame % 13U);
  const int16_t rightTearY = 38 + static_cast<int16_t>((frame + 7U) % 13U);
  display.drawBitmap(6, leftTearY, waterDropBitmap, 8, 12, SSD1306_WHITE);
  display.drawBitmap(114, rightTearY, waterDropBitmap, 8, 12, SSD1306_WHITE);
}

inline void drawWateringFaceFrame(Adafruit_SSD1306& display,
                                  int16_t,
                                  int16_t,
                                  uint32_t frame) {
  drawFallingDrop(display, 4, frame, 0U);
  drawFallingDrop(display, 60, frame, 25U);
  drawFallingDrop(display, 116, frame, 50U);
  drawRobotEyePair(display, frame + 8U, EYES_WATERING);
}

inline void drawBigSmileFaceFrame(Adafruit_SSD1306& display,
                                  int16_t,
                                  int16_t,
                                  uint32_t frame) {
  drawRobotEyePair(display, frame, EYES_HAPPY);
  if ((frame % 16U) < 8U) {
    drawRobotSparkle(display, 7, 7);
    drawRobotSparkle(display, 121, 7);
  }
}

inline void drawSleepingFaceFrame(Adafruit_SSD1306& display,
                                  int16_t,
                                  int16_t,
                                  uint32_t frame) {
  drawRoundedRobotEye(display, 37, 31, 38U, 4U, EYES_NORMAL, true);
  drawRoundedRobotEye(display, 91, 31, 38U, 4U, EYES_NORMAL, false);

  const uint8_t bubbleRadius = 2U + ((frame % 24U) / 8U);
  display.drawCircle(116, 12, bubbleRadius, SSD1306_WHITE);
}

inline void drawTearFrame(Adafruit_SSD1306& display,
                          int16_t x,
                          int16_t y,
                          uint32_t frame) {
  display.drawBitmap(x, y + (frame % 6U), waterDropBitmap, 8, 12, SSD1306_WHITE);
}

inline void drawWaterDrops(Adafruit_SSD1306& display,
                           int16_t x,
                           int16_t y,
                           uint32_t frame) {
  const uint8_t cycle = frame % 4U;
  display.drawBitmap(x, y + cycle * 2, waterDropBitmap, 8, 12, SSD1306_WHITE);
  display.drawBitmap(x + 10, y + ((cycle + 2U) % 4U) * 2 + 8,
                     waterDropBitmap, 8, 12, SSD1306_WHITE);
  display.drawBitmap(x + 20, y + ((cycle + 1U) % 4U) * 2 + 4,
                     waterDropBitmap, 8, 12, SSD1306_WHITE);
}

