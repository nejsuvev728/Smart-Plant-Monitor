# Smart Plant Monitoring System

An ESP32 based smart plant monitor with real time sensing, automatic watering, an animated OLED interface, and a Blynk IoT dashboard.

## Features

- ESP32-WROOM-32 firmware
- Blynk IoT cloud dashboard
- SSD1306 128x64 I2C OLED interface
- DHT11 temperature and humidity monitoring
- FC-28 / YL-69 analog soil moisture monitoring
- L298N controlled water pump with PWM
- Active buzzer for dry soil alerts
- Automatic and manual watering modes
- Non-blocking `millis()` based control logic
- Animated plant and robot-style OLED states
- Periodic sensor and system status reporting

## Repository Structure

```text
Smart-Plant-Monitor/
├── PlantMonitor.ino
├── config.example.h
├── animations.h
├── bitmaps.h
├── .gitignore
├── LICENSE
└── README.md
```

`config.h` is intentionally not included. Copy `config.example.h` to `config.h`, then add your private WiFi and Blynk credentials.

## Hardware

| Component | Connection |
|---|---|
| SSD1306 SDA | GPIO21 |
| SSD1306 SCL | GPIO22 |
| SSD1306 VCC | 3.3V |
| SSD1306 GND | GND |
| DHT11 DATA | GPIO4 |
| DHT11 VCC | 3.3V |
| DHT11 GND | GND |
| Soil sensor AO | GPIO34 |
| Soil sensor VCC | 3.3V |
| Soil sensor GND | GND |
| L298N ENA | GPIO25, PWM |
| L298N IN1 | GPIO26 |
| L298N IN2 | GPIO33 |
| Buzzer + | GPIO27 |
| Buzzer - | GND |

For the L298N, remove the ENA jumper so GPIO25 can control the pump speed.

The pump uses the L298N motor output. Use a motor supply that matches the pump's rated voltage. Keep the ESP32 ground and motor driver ground common. Do not power the pump directly from the ESP32.

## Software Requirements

### Arduino IDE

Recommended board:

```text
ESP32 Dev Module
```

Upload speed:

```text
115200 or 921600
```

Partition scheme:

```text
Default 4MB with spiffs
```

### Libraries

Install these through the Arduino Library Manager:

- Blynk
- Adafruit SSD1306
- Adafruit GFX Library
- DHT sensor library
- Adafruit Unified Sensor

Built-in ESP32 libraries used:

- Wire
- WiFi

## Configuration

1. Copy `config.example.h` to `config.h`.
2. Open `config.h`.
3. Set your Blynk template ID.
4. Set your Blynk template name.
5. Set your Blynk authentication token.
6. Set your WiFi SSID and password.
7. Upload the sketch.

On macOS/Linux:

```bash
cp config.example.h config.h
```

On Windows PowerShell:

```powershell
Copy-Item config.example.h config.h
```

`config.h` is ignored by Git.

## Blynk Setup

Create a Blynk IoT template named `Smart Plant Care`.

Configure these datastreams:

| Virtual Pin | Type | Purpose |
|---|---|---|
| V0 | Double | Temperature |
| V1 | Double | Humidity |
| V2 | Integer | Soil moisture percentage |
| V3 | Integer | Manual pump switch |
| V4 | Integer | Automatic mode switch |
| V5 | Integer | Pump status |
| V6 | Integer | Dry soil alert |
| V7 | String | System status |

Recommended dashboard widgets:

- Temperature gauge, V0
- Humidity gauge, V1
- Soil moisture gauge, V2
- Manual pump button, V3
- Auto mode button, V4
- Pump status indicator, V5
- SuperChart using V0, V1 and V2
- System status display, V7

Create these Blynk events:

```text
soil_dry
pump_status
plant_healthy
system_status
```

## Soil Moisture Calibration

The default calibration is:

```cpp
SOIL_RAW_DRY = 4095
SOIL_RAW_WET = 1500
```

The firmware maps this range to:

```text
0%  = dry
100% = wet
```

For a better result, calibrate the sensor in your actual soil.

1. Open Serial Monitor.
2. Set the baud rate to `115200`.
3. Record the dry soil raw value.
4. Record the wet soil raw value.
5. Update `SOIL_RAW_DRY` and `SOIL_RAW_WET` in `config.h`.

## Watering Logic

### Automatic mode

```text
Soil < 35%  -> Pump ON
Soil > 60%  -> Pump OFF
```

The gap between the ON and OFF thresholds prevents rapid pump cycling around one moisture value.

### Manual mode

Turn Auto Mode off through Blynk, then use the Manual Pump control.

## OLED Interface

The OLED supports several animated states:

- Startup animation
- WiFi connection animation
- WiFi connected screen
- Healthy plant state
- Dry soil state
- Watering state
- Happy plant state
- Sleeping state
- Periodic full-screen sensor metrics

The normal state includes eye movement and blinking. Dry soil uses a sad expression and tears. Watering uses falling water drops. The happy state adds animated sparkles.

## Upload

1. Install the ESP32 board package in Arduino IDE.
2. Install the required libraries.
3. Copy `config.example.h` to `config.h`.
4. Add your credentials to `config.h`.
5. Open `PlantMonitor.ino`.
6. Select `ESP32 Dev Module`.
7. Select the correct serial port.
8. Compile the project.
9. Upload it to the ESP32.
10. Open Serial Monitor at `115200`.

## Production Notes

- FC-28 and YL-69 probes can corrode over time. A capacitive soil moisture sensor is more suitable for long term deployment.
- Pump speed is controlled by `PUMP_SPEED_PERCENT`.
- DHT11 works with this project, but DHT22 or SHT31 can provide better environmental measurements.
- Keep secrets in `config.h`. Never commit WiFi passwords or Blynk authentication tokens.

## Project Status

This repository contains the firmware and configuration template for the Smart Plant Monitoring System.

## License

MIT License. See `LICENSE`.
